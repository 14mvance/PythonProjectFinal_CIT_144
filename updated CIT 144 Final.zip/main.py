################################################################
## Final Project for CIT 144 Intro to Programming Using Python #
##              Textbook Quiz Application                      #
##   By:                                                       #
##      Casey James                                            #
##      Matthew Vance                                          #
##      Kyle Rust                                              #
################################################################


### Imports
from tkinter import *
from tkinter import messagebox
from Questions import *
import random


### GUI Class
class GUI:
    def __init__(self):

        ### Setting up a Window in tkinter at 600x180 resolution
        window = Tk()
        window.title("Introduction to Programming Using Python")
        window.geometry('1200x200')

        ### GUI Class Variables
        self.str_Question = StringVar()
        self._Answer = IntVar()
        self.answerOne = StringVar()
        self.answerTwo = StringVar()
        self.answerThree = StringVar()
        self.answerFour = StringVar()
        self.myAnswer = StringVar()
        self.correctAnswer = StringVar()
        self.chapter = IntVar() 
        self.questionNumber = IntVar()
        self._Chapter = IntVar()

        self.numQuestions = IntVar()
        self.RightAnswers = IntVar()
        self.TotalQuestions = IntVar()
 
        
        ### Frame 1 GUI Elements
        frame1 = Frame(window)
        frame1.pack()
        self.rbChapterOne = Radiobutton(frame1, text = "Chapter 1",  variable = self._Chapter, value = 1, command = self.chapterRadio)
        self.rbChapterTwo = Radiobutton(frame1, text = "Chapter 2",  variable = self._Chapter, value = 2, command = self.chapterRadio)
        self.rbChapterThree = Radiobutton(frame1, text = "Chapter 3",  variable = self._Chapter, value = 3, command = self.chapterRadio)
        self.rbChapterFour = Radiobutton(frame1, text = "Chapter 4",  variable = self._Chapter, value = 4, command = self.chapterRadio)
        self.rbChapterFive = Radiobutton(frame1, text = "Chapter 5",  variable = self._Chapter, value = 5, command = self.chapterRadio)
        self.rbChapterSix = Radiobutton(frame1, text = "Chapter 6",  variable = self._Chapter, value = 6, command = self.chapterRadio)
        self.rbChapterSeven = Radiobutton(frame1, text = "Chapter 7",  variable = self._Chapter, value = 7, command = self.chapterRadio)
        self.rbChapterEight = Radiobutton(frame1, text = "Chapter 8",  variable = self._Chapter, value = 8, command = self.chapterRadio)
        self.rbChapterNine = Radiobutton(frame1, text = "Chapter 9",  variable = self._Chapter, value = 9, command = self.chapterRadio)
        self.rbChapterTen = Radiobutton(frame1, text = "Chapter 10",  variable = self._Chapter, value = 10, command = self.chapterRadio)
        self.rbChapterEleven = Radiobutton(frame1, text = "Chapter 11",  variable = self._Chapter, value = 11, command = self.chapterRadio)
        self.rbChapterTwelve = Radiobutton(frame1, text = "Chapter 12",  variable = self._Chapter, value = 12, command = self.chapterRadio)
        self.rbChapterThirteen = Radiobutton(frame1, text = "Chapter 13",  variable = self._Chapter, value = 13, command = self.chapterRadio)
        self.rbChapterFourteen = Radiobutton(frame1, text = "Chapter 14",  variable = self._Chapter, value = 14, command = self.chapterRadio)
        self.rbChapterFifteen = Radiobutton(frame1, text = "Chapter 15",  variable = self._Chapter, value = 15, command = self.chapterRadio)
        self.rbChapterAll = Radiobutton(frame1, text = "All Chapters", variable = self._Chapter, value = 16, command = self.chapterRadio)

       
        self.rbChapterOne.grid(row = 0, column = 0, sticky = W)
        self.rbChapterTwo.grid(row = 0, column = 1, sticky = W)
        self.rbChapterThree.grid(row = 0, column = 2, sticky = W)
        self.rbChapterFour.grid(row = 0, column = 3, sticky = W)
        self.rbChapterFive.grid(row = 0, column = 4, sticky = W)
        self.rbChapterSix.grid(row = 0, column = 5, sticky = W)
        self.rbChapterSeven.grid(row = 0, column = 6, sticky = W)
        self.rbChapterEight.grid(row = 0, column = 7, sticky = W)
        self.rbChapterNine.grid(row = 1, column = 0, sticky = W)
        self.rbChapterTen.grid(row = 1, column = 1, sticky = W)
        self.rbChapterEleven.grid(row = 1, column = 2, sticky = W)
        self.rbChapterTwelve.grid(row = 1, column = 3, sticky = W)
        self.rbChapterThirteen.grid(row = 1, column = 4, sticky = W)
        self.rbChapterFourteen.grid(row = 1, column = 5, sticky = W)
        self.rbChapterFifteen.grid(row = 1, column = 6, sticky = W)
        self.rbChapterAll.grid(row = 1, column = 7, sticky = W)
        
        
        ### Frame 2 GUI Elements
        frame2 = Frame(window)
        frame2.pack()

        self.lblQuestion = Label(frame2, text = "Question: ")
        self.lblQuestion.grid(column = 0, columnspan = 5, sticky = W)

        ### Frame 3 GUI Elements
        frame3 = Frame(window)
        frame3.pack()
        self.btBeginQuiz = Button(frame3, text = "Begin Quiz", command = self.BeginQuiz)
        self.btSubmitAnswer = Button(frame3, text = "Submit Answer", command = self.SubmitButton)
             
        self.rbAnswerOne = Radiobutton(frame3, textvariable = self.answerOne, variable = self._Answer, value = 1, command = self.processRadioButton)
        self.rbAnswerTwo = Radiobutton(frame3, textvariable = self.answerTwo, variable = self._Answer, value = 2, command = self.processRadioButton)
        self.rbAnswerThree = Radiobutton(frame3, textvariable = self.answerThree, variable = self._Answer, value = 3, command = self.processRadioButton)
        self.rbAnswerFour = Radiobutton(frame3, textvariable = self.answerFour, variable = self._Answer, value = 4, command = self.processRadioButton)

        self.rbAnswerOne.grid(row = 0, column = 0, sticky = W)
        self.rbAnswerTwo.grid(row = 1, column = 0, sticky = W)
        self.rbAnswerThree.grid(row = 2, column = 0, sticky = W)
        self.rbAnswerFour.grid(row = 3, column = 0, sticky = W)
        self.btBeginQuiz.grid(row = 4, column = 0, sticky = W)
        self.btSubmitAnswer.grid(row = 4, column = 1, sticky = W)
        
        

        self.setup_gui(False)
        window.mainloop()

    def setup_gui(self, in_quiz):
        if in_quiz:
            self.rbChapterOne.grid_remove()
            self.rbChapterTwo.grid_remove()
            self.rbChapterThree.grid_remove()
            self.rbChapterFour.grid_remove()
            self.rbChapterFive.grid_remove()
            self.rbChapterSix.grid_remove()
            self.rbChapterSeven.grid_remove()
            self.rbChapterEight.grid_remove()
            self.rbChapterNine.grid_remove()
            self.rbChapterTen.grid_remove()
            self.rbChapterEleven.grid_remove()
            self.rbChapterTwelve.grid_remove()
            self.rbChapterThirteen.grid_remove()
            self.rbChapterFourteen.grid_remove()
            self.rbChapterFifteen.grid_remove()
            self.rbChapterAll.grid_remove()
            self.lblQuestion.grid()
            self.rbAnswerOne.grid()
            self.rbAnswerTwo.grid()
            self.rbAnswerThree.grid()
            self.rbAnswerFour.grid()
            self.btBeginQuiz.grid_remove()
            self.btSubmitAnswer.grid()
        else:
            self.rbChapterOne.grid()
            self.rbChapterTwo.grid()
            self.rbChapterThree.grid()
            self.rbChapterFour.grid()
            self.rbChapterFive.grid()
            self.rbChapterSix.grid()
            self.rbChapterSeven.grid()
            self.rbChapterEight.grid()
            self.rbChapterNine.grid()
            self.rbChapterTen.grid()
            self.rbChapterEleven.grid()
            self.rbChapterTwelve.grid()
            self.rbChapterThirteen.grid()
            self.rbChapterFourteen.grid()
            self.rbChapterFifteen.grid()
            self.rbChapterAll.grid()
            self.lblQuestion.grid_remove()
            self.rbAnswerOne.grid_remove()
            self.rbAnswerTwo.grid_remove()
            self.rbAnswerThree.grid_remove()
            self.rbAnswerFour.grid_remove()
            self.btBeginQuiz.grid()
            self.btSubmitAnswer.grid_remove()

    def Results(self):
        self.setup_gui(False)
        correct = self.RightAnswers.get()
        total = self.TotalQuestions.get()
        percent = (correct / total) * 100

        if (percent <= 59):
            grade = 'F'
        if (percent >= 60):
            grade = 'D'
        if (percent >= 70):
            grade = 'C'
        if (percent >= 80):
            grade = 'B'
        if (percent >= 90):
            grade = 'A'
            
        self.str_Question.set("Question: ")
        self.answerOne.set("A:")
        self.answerTwo.set("B:")
        self.answerThree.set("C:")
        self.answerFour.set("D:")
        messagebox.showinfo("Results", "You scored: " + str(correct) + " out of " + str(total) + \
                            "\nPercent: " + str(percent) + \
                            "\nGrade: " + grade)
        self.RightAnswers.set(0)
        self.TotalQuestions.set(0)

        


    def BeginQuiz(self):
        self.setup_gui(True)
        if self.chapter.get() == None:
            return
        if (self.chapter.get() == 16):
            self.numQuestions.set(30)
        else:
            self.numQuestions.set(5)
            
        self.questionNumber.set(1) 
        self.Create_Question(self.chapter.get(), self.questionNumber.get())
        self.lblQuestion["text"] = self.str_Question.get()

    ### These Radio buttons determine what chapter the user is currently working on
    def chapterRadio(self):
        self.chapter.set(self._Chapter.get())
       


    ### This button submits the current answer for grading and then asks for antoher question
    def SubmitButton(self):
        if (self.myAnswer.get() == self.correctAnswer.get()):
            self.RightAnswers.set(self.RightAnswers.get() + 1)
        
        self.TotalQuestions.set(self.TotalQuestions.get() + 1)
            

        self.questionNumber.set(self.questionNumber.get()+1)
        self.Create_Question(self.chapter.get(), self.questionNumber.get())
        self.lblQuestion["text"] = self.str_Question.get()

        self._Answer.set(0)

        
    ### These Radio Buttons are the choices for the answers                
    def processRadioButton(self):
        if (self._Answer.get() == 1):
            self.myAnswer.set(self.answerOne.get())
        if (self._Answer.get() == 2):
            self.myAnswer.set(self.answerTwo.get())
        if (self._Answer.get() == 3):
            self.myAnswer.set(self.answerThree.get())
        if (self._Answer.get() == 4):
            self.myAnswer.set(self.answerFour.get())
        
   
    ### Uses the Questions.py file to create questions    
    def Create_Question(self, chapter, number):
        if (number <= self.numQuestions.get()): # If 5 questions haven't been asked, then it asks another
            
            ### Just chooses which chapter to quiz over, based on the user's radio button selection
            if (chapter == 1):
                chapterQuestions = chapter1_Questions
                chapterAnswers = chapter1_Answers
                
            if (chapter == 2):
                chapterQuestions = chapter2_Questions
                chapterAnswers = chapter2_Answers
                
            if (chapter == 3):
                chapterQuestions = chapter3_Questions
                chapterAnswers = chapter3_Answers
                
            if (chapter == 4):
                chapterQuestions = chapter4_Questions
                chapterAnswers = chapter4_Answers
                
            if (chapter == 5):
                chapterQuestions = chapter5_Questions
                chapterAnswers = chapter5_Answers
                
            if (chapter == 6):
                chapterQuestions = chapter6_Questions
                chapterAnswers = chapter6_Answers
                
            if (chapter == 7):
                chapterQuestions = chapter7_Questions
                chapterAnswers = chapter7_Answers
                
            if (chapter == 8):
                chapterQuestions = chapter8_Questions
                chapterAnswers = chapter8_Answers
                
            if (chapter == 9):
                chapterQuestions = chapter9_Questions
                chapterAnswers = chapter9_Answers
                
            if (chapter == 10):
                chapterQuestions = chapter10_Questions
                chapterAnswers = chapter10_Answers
                
            if (chapter == 11):
                chapterQuestions = chapter11_Questions
                chapterAnswers = chapter11_Answers
                
            if (chapter == 12):
                chapterQuestions = chapter12_Questions
                chapterAnswers = chapter12_Answers
                
            if (chapter == 13):
                chapterQuestions = chapter13_Questions
                chapterAnswers = chapter13_Answers
                
            if (chapter == 14):
                chapterQuestions = chapter14_Questions
                chapterAnswers = chapter14_Answers
                
            if (chapter == 15):
                chapterQuestions = chapter15_Questions
                chapterAnswers = chapter15_Answers

            if (chapter == 16):
                if (self.questionNumber.get() <= 2):
                    chapterQuestions = chapter1_Questions
                    chapterAnswers = chapter1_Answers
                elif (self.questionNumber.get() <= 4):
                    chapterQuestions = chapter2_Questions
                    chapterAnswers = chapter2_Answers
                elif (self.questionNumber.get() <= 6):
                    chapterQuestions = chapter3_Questions
                    chapterAnswers = chapter3_Answers

                elif (self.questionNumber.get() <= 8):
                    chapterQuestions = chapter4_Questions
                    chapterAnswers = chapter4_Answers
                elif (self.questionNumber.get() <= 10):
                    chapterQuestions = chapter5_Questions
                    chapterAnswers = chapter5_Answers
                elif (self.questionNumber.get() <= 12):
                    chapterQuestions = chapter6_Questions
                    chapterAnswers = chapter6_Answers

                elif (self.questionNumber.get() <= 14):
                    chapterQuestions = chapter7_Questions
                    chapterAnswers = chapter7_Answers
                elif (self.questionNumber.get() <= 16):
                    chapterQuestions = chapter8_Questions
                    chapterAnswers = chapter8_Answers
                elif (self.questionNumber.get() <= 18):
                    chapterQuestions = chapter9_Questions
                    chapterAnswers = chapter9_Answers

                elif (self.questionNumber.get() <= 20):
                    chapterQuestions = chapter10_Questions
                    chapterAnswers = chapter10_Answers
                elif (self.questionNumber.get() <= 22):
                    chapterQuestions = chapter11_Questions
                    chapterAnswers = chapter11_Answers
                elif (self.questionNumber.get() <= 24):
                    chapterQuestions = chapter12_Questions
                    chapterAnswers = chapter12_Answers

                elif (self.questionNumber.get() <= 26):
                    chapterQuestions = chapter13_Questions
                    chapterAnswers = chapter13_Answers
                elif (self.questionNumber.get() <= 28):
                    chapterQuestions = chapter14_Questions
                    chapterAnswers = chapter14_Answers
                else:
                    chapterQuestions = chapter15_Questions
                    chapterAnswers = chapter15_Answers

 
            MAX = len(chapterQuestions) # Asks a question within the range of the chapter (0 to However many questions there are in that particular chapter)
            question = random.randint(0, MAX -1) # Creates the current question
            correct = chapterAnswers[question] # Gets the correct answer associated with current question
            quiz_Answers = [] # List used to store current answer choices
            quiz_Answers.append(correct) # Makes sure that the correct answer is added to the list of choices
            self.correctAnswer.set(correct) # Stores the correct answer in a GUI class variable, so that the test can be graded properly

       
            self.str_Question.set(str(number) + ": " + chapterQuestions[question] + "?") # Creates the string that is seen on the Question Label

            ### Creates 3 additional choices besides the correct answer for our multiple choice questions
            i = 0
            while i < 3:
                nextAnswer = random.randint(0, MAX-1) # Finds a random answer from the chapter
                if chapterAnswers[nextAnswer] in quiz_Answers:
                    continue

                else:
                    quiz_Answers.append(chapterAnswers[nextAnswer]) # Adds the random answer to the list of choices
                    i += 1



            random.shuffle(quiz_Answers) # Shuffles the answer choices, so that the correct answer isn't always in the same spot

            ### Sets all of the answers in GUI class Variables, so that the Radio Buttons can use them
            self.answerOne.set(quiz_Answers[0])
            self.answerTwo.set(quiz_Answers[1])
            self.answerThree.set(quiz_Answers[2])
            self.answerFour.set(quiz_Answers[3])

        ### If 5 questions have been asked then results are given
        else:           
            self.Results()

       
        


GUI()

        
